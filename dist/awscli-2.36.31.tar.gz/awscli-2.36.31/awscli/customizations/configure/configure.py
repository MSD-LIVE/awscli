# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
import logging
import os
import sys

from botocore.exceptions import ProfileNotFound

from awscli.compat import compat_input
from awscli.customizations.agenttoolkit.configure import (
    ConfigureAgentToolkitCommand,
)
from awscli.customizations.commands import BasicCommand
from awscli.customizations.configure.addmodel import AddModelCommand
from awscli.customizations.configure.exportcreds import (
    ConfigureExportCredentialsCommand,
)
from awscli.customizations.configure.get import ConfigureGetCommand
from awscli.customizations.configure.importer import ConfigureImportCommand
from awscli.customizations.configure.list import ConfigureListCommand
from awscli.customizations.configure.listprofiles import ListProfilesCommand
from awscli.customizations.configure.mfalogin import ConfigureMFALoginCommand
from awscli.customizations.configure.set import ConfigureSetCommand
from awscli.customizations.configure.sso_commands import (
    ConfigureSSOCommand,
    ConfigureSSOSessionCommand,
)
from awscli.customizations.configure.writer import ConfigFileWriter

from . import mask_value, profile_to_section

logger = logging.getLogger(__name__)


def register_configure_cmd(cli):
    cli.register('building-command-table.main', ConfigureCommand.add_command)


class InteractivePrompter:
    def get_value(self, current_value, config_name, prompt_text=''):
        if config_name in (
            'aws_access_key_id',
            'aws_secret_access_key',
            'aws_session_token',
        ):
            current_value = mask_value(current_value)
        response = compat_input(f"{prompt_text} [{current_value}]: ")
        if not response:
            # If the user hits enter, we return a value of None
            # instead of an empty string.  That way we can determine
            # whether or not a value has changed.
            response = None
        return response


class ConfigureCommand(BasicCommand):
    NAME = 'configure'
    DESCRIPTION = BasicCommand.FROM_FILE()
    SYNOPSIS = 'aws configure [--profile profile-name]'
    EXAMPLES = (
        'To create a new configuration::\n'
        '\n'
        '    $ aws configure\n'
        '    Tip: You can deliver temporary credentials to the AWS CLI using \n'
        '    your AWS Console session by running the command \'aws login\'.\n\n'
        '    AWS Access Key ID [None]: accesskey\n'
        '    AWS Secret Access Key [None]: secretkey\n'
        '    Default region name [None]: us-west-2\n'
        '    Default output format [None]:\n'
        '\n'
        'To update just the region name::\n'
        '\n'
        '    $ aws configure\n'
        '    AWS Access Key ID [****]:\n'
        '    AWS Secret Access Key [****]:\n'
        '    Default region name [us-west-1]: us-west-2\n'
        '    Default output format [None]:\n'
    )
    SUBCOMMANDS = [
        {'name': 'list', 'command_class': ConfigureListCommand},
        {'name': 'get', 'command_class': ConfigureGetCommand},
        {'name': 'set', 'command_class': ConfigureSetCommand},
        {'name': 'add-model', 'command_class': AddModelCommand},
        {'name': 'import', 'command_class': ConfigureImportCommand},
        {'name': 'list-profiles', 'command_class': ListProfilesCommand},
        {'name': 'sso', 'command_class': ConfigureSSOCommand},
        {'name': 'sso-session', 'command_class': ConfigureSSOSessionCommand},
        {'name': 'mfa-login', 'command_class': ConfigureMFALoginCommand},
        {
            'name': 'export-credentials',
            'command_class': ConfigureExportCredentialsCommand,
        },
        {
            'name': 'agent-toolkit',
            'command_class': ConfigureAgentToolkitCommand,
        },
    ]

    # If you want to add new values to prompt, update this list here.
    VALUES_TO_PROMPT = [
        # (logical_name, config_name, prompt_text)
        ('aws_access_key_id', "AWS Access Key ID"),
        ('aws_secret_access_key', "AWS Secret Access Key"),
        ('aws_session_token', "AWS Session Token"),
        ('region', "Default region name"),
        ('output', "Default output format"),
    ]

    def __init__(self, session, prompter=None, config_writer=None):
        super().__init__(session)
        if prompter is None:
            prompter = InteractivePrompter()
        self._prompter = prompter
        if config_writer is None:
            config_writer = ConfigFileWriter()
        self._config_writer = config_writer

    def _needs_session_token(self, new_values):
        """Check if session token is needed based on access key ID."""
        access_key = new_values.get('aws_access_key_id')
        return access_key and access_key.startswith('ASIA')

    def _should_prompt_for_session_token(self, new_values, config):
        """Determine if we should prompt for session token."""
        # Don't prompt if explicitly switching to long-term credentials
        new_access_key = new_values.get('aws_access_key_id')
        if new_access_key and not self._needs_session_token(new_values):
            return False

        # Prompt if needed for temporary credentials or if already exists
        return self._needs_session_token(new_values) or config.get(
            'aws_session_token'
        )

    def _run_main(self, parsed_args, parsed_globals):
        # Called when invoked with no args "aws configure"

        new_values = {}
        # This is the config from the config file scoped to a specific
        # profile.
        try:
            config = self._session.get_scoped_config()
        except ProfileNotFound:
            config = {}

        if not config:
            sys.stdout.write(
                '\nTip: You can deliver temporary credentials to the AWS '
                'CLI using your AWS Console session by running the command '
                '\'aws login\'.\n\n'
            )

        for config_name, prompt_text in self.VALUES_TO_PROMPT:
            if (
                config_name == 'aws_session_token'
                and not self._should_prompt_for_session_token(
                    new_values, config
                )
            ):
                continue

            current_value = config.get(config_name)
            new_value = self._prompter.get_value(
                current_value, config_name, prompt_text
            )
            if new_value is not None and new_value != current_value:
                new_values[config_name] = new_value

        # Remove session token for non-temporary credentials
        if (
            'aws_access_key_id' in new_values
            and not self._needs_session_token(new_values)
            and config.get('aws_session_token')
        ):
            new_values['aws_session_token'] = None
        config_filename = os.path.expanduser(
            self._session.get_config_variable('config_file')
        )
        if new_values:
            profile = self._session.profile
            self._write_out_creds_file_values(new_values, profile)
            if profile is not None:
                section = profile_to_section(profile)
                new_values['__section__'] = section
            self._config_writer.update_config(new_values, config_filename)
        return 0

    def _write_out_creds_file_values(self, new_values, profile_name):
        # The access_key/secret_key are now *always* written to the shared
        # credentials file (~/.aws/credentials), see aws/aws-cli#847.
        # post-conditions: ~/.aws/credentials will have the updated credential
        # file values and new_values will have the cred vars removed.
        credential_file_values = {}
        if 'aws_access_key_id' in new_values:
            credential_file_values['aws_access_key_id'] = new_values.pop(
                'aws_access_key_id'
            )
        if 'aws_secret_access_key' in new_values:
            credential_file_values['aws_secret_access_key'] = new_values.pop(
                'aws_secret_access_key'
            )
        if 'aws_session_token' in new_values:
            credential_file_values['aws_session_token'] = new_values.pop(
                'aws_session_token'
            )
        if credential_file_values:
            if profile_name is not None:
                credential_file_values['__section__'] = profile_name
            shared_credentials_filename = os.path.expanduser(
                self._session.get_config_variable('credentials_file')
            )
            self._config_writer.update_config(
                credential_file_values,
                shared_credentials_filename,
                check_permissions=True,
            )
